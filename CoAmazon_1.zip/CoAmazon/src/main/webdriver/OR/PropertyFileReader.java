package OR;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class PropertyFileReader {


public File file;
public FileInputStream input;
public Properties properties;

public String getFilePath(){
	String userDir=System.getProperty("user.dir");
	return userDir;
}


public String getPropertyValueOf(String filepath,String Key){	
	file = new File(getFilePath()+filepath);
	try {
	input = new FileInputStream(file);
	} catch (FileNotFoundException e) {
		System.out.println("Properties file not found");
		
	}
	properties = new Properties();
	try {
		properties.load(input);
	} catch (IOException e) {
	System.out.println("Cannot read OR file");
	}
	return properties.getProperty(Key);
}
}
