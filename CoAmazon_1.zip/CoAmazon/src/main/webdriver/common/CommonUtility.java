package common;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Properties;
import java.util.Date;
import org.apache.commons.io.FileUtils;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.Augmenter;
import org.testng.Reporter;

public class CommonUtility extends DriverSetup{
	private Date date;

	public String getPropertiesConfigValue(String property) {

		Properties props = new Properties();
		InputStream is = null;
		String userDir = System.getProperty("user.dir");
		String propertyPath = userDir + "/src/resources/Properties/ProjectConfig.properties";

		try {
			File f = new File(propertyPath);
			is = new FileInputStream(f);
			props.load(is);
		} catch (IOException e) {
			is = null;
		}

		return props.getProperty(property);
	}

	public String getPropertiesValue(String property) {
		/* code to fetch values from properties file */
		Properties props = new Properties();
		InputStream is = null;
		String userDir = System.getProperty("user.dir");
		String propertyPath = userDir + "/src/resources/Properties/SuiteConfig.properties";
		// First try loading from the current directory
		try {
			File f = new File(propertyPath);
			is = new FileInputStream(f);
		} catch (Exception e) {
			is = null;
		}
		try {
			props.load(is);
		} catch (IOException e) {
			e.printStackTrace();
		}

		return props.getProperty("TotalTestCount");
	}

	public void updateTestCaseXLS(String currentTestName, String currentSheetName, String ExeStatus)
			throws InvalidFormatException, IOException, NullPointerException {
		// TODO Auto-generated method stub

		String userDir = System.getProperty("user.dir");
		String propertyPath = userDir + "/src/resources/TestCase/TestCase.xlsx";

		File file = new File(propertyPath);
		FileInputStream fis = new FileInputStream(file);

		Workbook wb = WorkbookFactory.create(fis);
		Sheet sheet = wb.getSheet(currentSheetName);
		CellStyle style = wb.createCellStyle();
		Font font = wb.createFont();
		font.setFontName("Arial");

		int rowLimit = sheet.getLastRowNum();

		// Row row = null;
		for (int i = 2; i <= rowLimit; i++) {

			Row row = sheet.getRow(i);

			// Get TestName details
			Cell cellRunStatID = row.getCell(1);
			try {
				String TestName = cellRunStatID.getStringCellValue().toString();
				// System.out.println(TestName);

				if (TestName.equalsIgnoreCase(currentTestName)) {

					if (ExeStatus.equalsIgnoreCase("pass")) {

						// style.setFillBackgroundColor(IndexedColors.LIGHT_GREEN.getIndex());
						// style.setFillPattern(CellStyle.ALIGN_FILL);
						font.setColor(IndexedColors.GREEN.getIndex());
						style.setFont(font);
						Cell cellStatus = row.createCell(8);
						cellStatus.setCellStyle(style);
						cellStatus.setCellValue("Pass");

					}
					if (ExeStatus.equalsIgnoreCase("Fail")) {

						// style.setFillBackgroundColor(IndexedColors.RED.getIndex());
						// style.setFillPattern(CellStyle.ALIGN_FILL);
						font.setColor(IndexedColors.RED.getIndex());
						style.setFont(font);
						Cell cellStatus = row.createCell(8);
						cellStatus.setCellStyle(style);
						cellStatus.setCellValue("Fail");
					}
					if (ExeStatus.equalsIgnoreCase("Skip")) {

						// style.setFillBackgroundColor(IndexedColors.TAN.getIndex());
						// style.setFillPattern(CellStyle.ALIGN_FILL);
						font.setColor(IndexedColors.BLUE.getIndex());
						style.setFont(font);
						Cell cellStatus = row.createCell(8);
						cellStatus.setCellStyle(style);
						cellStatus.setCellValue("Skip");
					}
					// Cell cellStatus = row.createCell(8);
					// cellStatus.setCellValue(ExeStatus);
				}
			} catch (Exception ex) {
			}
		}
		FileOutputStream fileOut = new FileOutputStream(file);
		wb.write(fileOut);
		fileOut.close();
		// Write the output to a file

	}

	public String getcurrentDateTime() {
		String dateandTime = null;

		Calendar cal = new GregorianCalendar();

		int day = cal.get(Calendar.DAY_OF_MONTH);
		// Added to match georgian calendar to current month
		cal.add(Calendar.MONTH, 1);
		int month = cal.get(Calendar.MONTH);
		int year = cal.get(Calendar.YEAR);

		int second = cal.get(Calendar.SECOND);
		int minute = cal.get(Calendar.MINUTE);
		int hour = cal.get(Calendar.HOUR);
		dateandTime = year + "/" + day + "/" + month + "   " + hour + ":" + minute + ":" + second;
		return dateandTime;
	}

	public String getScreenShot(WebDriver driver, String currentBrowser, String failedClass, String screenShotPath) {

		System.out.println("getScreenShot....#");
		String newFileNamePath = null;
		String imageName = null;
		Calendar calendar = null;
		DateFormat dateFormat = null;
		File screenshot = null;
		if (!driver.getClass().getCanonicalName().contains("htmlunit")) {
			try {
				// s_logger.write("entered simplesearchAddRooms_normal
				// sequence");
				WebDriver augmentedDriver = new Augmenter().augment(driver);
				File directory = new File(".");

				calendar = Calendar.getInstance();
				date = calendar.getTime();
				dateFormat = new SimpleDateFormat("dd_MMM_yyyy__HH_mm_ss");

				screenshot = ((TakesScreenshot) augmentedDriver).getScreenshotAs(OutputType.BYTES.FILE);
				imageName = "_" + currentBrowser + "_" + failedClass + "_" + dateFormat.format(date) + ".png";
				if (screenShotPath.isEmpty())
					newFileNamePath = System.getProperty("user.dir") + "/screenshots/" + imageName;
				else
					newFileNamePath = System.getProperty("user.dir") + "/screenshots/" + "/" + imageName;

				System.out.println("NewFileNamePath :" + newFileNamePath);

				FileUtils.copyFile(screenshot, new File(newFileNamePath));
				newFileNamePath = "../../" + "screenshots/" + imageName;
				if (screenShotPath.equalsIgnoreCase("NA")) {
					newFileNamePath = "../../" + "NA/" + imageName;
				}
				Reporter.log(newFileNamePath);
				// s_logger.write("exiting simplesearchAddRooms_normal
				// sequence");
			} catch (org.openqa.selenium.WebDriverException e) {
				// s_logger.write("entered
				// simplesearchAddRooms_WebDriverException_catch sequence");
				calendar = Calendar.getInstance();
				// sFormatedDate = formatedDate(calendar, sFormat);

				date = calendar.getTime();
				dateFormat = new SimpleDateFormat("dd_MMM_yyyy__HH_mm_ss");
				screenshot = new File(System.getProperty("user.dir") + "/src/resources/noScreenShot.png");
				try {
					imageName = "_" + currentBrowser + "_" + failedClass + "_" + dateFormat.format(date) + ".png";
					newFileNamePath = System.getProperty("user.dir") + "/screenshots/" + imageName;
					System.out.println("NewFileNamePath :" + newFileNamePath);
					FileUtils.copyFile(screenshot, new File(newFileNamePath));
				} catch (IOException e1) {

					e1.printStackTrace();
				}
				e.printStackTrace();
				// s_logger.write("exiting
				// simplesearchAddRooms_WebDriverException_catch sequence");
			} catch (IOException e) {
			}
		} else
			newFileNamePath = "No Screenshot, running HTML UNIT";
		return newFileNamePath;
	}
	
	
	public String getPropertyValueForScreenShot() {

		Properties prop = new Properties();
		String s2 = System.getProperty("user.dir");
		String path = s2 + "/src/resources/ScreenShotFlag.properties";
		try {
			prop.load(new FileInputStream(path));
		} catch (Exception e) {

		}
		String value = prop.getProperty("TCScreenShotFlag");
		return value;
	}
}
