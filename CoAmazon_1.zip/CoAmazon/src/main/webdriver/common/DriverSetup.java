package common;

import java.awt.AWTException;
import java.awt.Desktop;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Proxy;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.xml.XmlSuite;
import org.testng.xml.XmlTest;

import OR.PropertyFileReader;
import common.DriverSetup.selectedBrowser;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;

public class DriverSetup {

	public static String browser;
	private static ChromeDriverService service = null;
	static DesiredCapabilities capabilities = null;
	public AppiumDriver driver = null;
	public String language;
	private static String gridStatus;
	private String tcSheetName;
	public String baseURL;
	public static String testName;
	public String testURL;
	public String ibeURL;
	public String xpathFilePath = null;
	public String languageFilePath = null;
	public String description = null;
	public String browserversion = null;
	public static boolean suitesNotStarted = true;
	int testTotalCount;
	int currentTestCount;
	public String screnshotfilepath;
	CreateDynamicSuite cds;
	public PropertyFileReader propertyfilereader;
	public String filepathOR = "/src/main/webdriver/OR/OR.properties";
	public String filepathAppConfig = "/src/main/webdriver/OR/ApplicationConfig.properties";
	public String filepathCap = "/src/main/webdriver/OR/DesiredCapabilities.properties";

	public int getTestCount() {
		return testTotalCount;
	}

	public enum selectedBrowser {
		iOS_Native, Android_Native;
	}

	@BeforeSuite
	public void setUp(ITestContext context) throws IOException, InterruptedException, AWTException {
		XmlSuite xmlSuite = context.getSuite().getXmlSuite();
		Map<String, String> allParameters = xmlSuite.getAllParameters();
		gridStatus = "FALSE";
		tcSheetName = allParameters.get("tcSheetName"); // Added to get testcase
														// sheet name
		cds = new CreateDynamicSuite();
		List<XmlTest> testList = xmlSuite.getTests();
		currentTestCount = 1;

		if (gridStatus.equalsIgnoreCase("true")) {
			if (suitesNotStarted) {

				suitesNotStarted = false;
			}
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		File myFile = new File(".//src//resources//TestData.xls");
	}

	public int getCurrentTestCount() {
		return currentTestCount;
	}

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(AndroidDriver driver) {
		this.driver = driver;
	}

	@BeforeTest
	@Parameters({ "browser", "browserversion", "url", "IBEurl", "gridFlag", "languagexls", "language",
			"delaybetweenscripts", "xpathXLS", "description", "testName", "testURL", "screnshotfilepath", "Newparam",
			"tcSheetName" })

	public void testSetup(@Optional("firefox") String browser, @Optional("0") String browserversion,
			@Optional("false") String url, @Optional("false") String IBEurl, @Optional("false") String gridFlag,
			@Optional("false") String languageXLS, @Optional("english") String language,
			@Optional("5") String delayBetweenScripts, @Optional("english") String xpathFilepath,
			@Optional("") String description, @Optional("") String testName, @Optional("") String testURL,
			@Optional("") String screnshotfilepath, @Optional("") String NEWPARAM, @Optional("") String tcSheetName)

			throws MalformedURLException, InterruptedException, StaleElementReferenceException {
		Integer startUpDelaySec = Integer.parseInt(delayBetweenScripts);
		Thread.sleep(startUpDelaySec * 1000);
		this.browser = browser;
		baseURL = url;
		this.language = language;
		this.description = description;
		this.browserversion = browserversion;
		this.testName = testName;
		this.testURL = testURL;
		ibeURL = IBEurl;
		this.screnshotfilepath = screnshotfilepath;
		this.tcSheetName = tcSheetName;
		if (gridFlag.equalsIgnoreCase("false")) {

			this.languageFilePath = languageXLS;
			this.xpathFilePath = xpathFilepath;

		} else if (gridFlag.equalsIgnoreCase("true")) {

			try {

				this.driver = (AppiumDriver) getRemoteDriver(getCapabilities());
				System.out.println("Driver instance is  " + driver);
				this.languageFilePath = languageXLS;
				this.xpathFilePath = xpathFilepath;
			} catch (MalformedURLException e) {

				e.printStackTrace();
			} catch (org.openqa.selenium.WebDriverException e) {
				Assert.fail("Seems grid was not initialized propertly,  this test is failed", e);
			}

		}

	}

	public String getScrenshotfilepath() {
		return screnshotfilepath;
	}

	public String getBrowserversion() {
		return browserversion;
	}

	public String getDescription() {
		return description;
	}

	public String getBrowser() {
		return browser;
	}

	public String getLanguage() {
		return language;
	}

	public String getCurrentSuiteSheetName() {
		return tcSheetName;
	}

	public String getTestName() {
		return testName;
	}

	public String getTestURL() {
		return testURL;
	}

	@BeforeClass(alwaysRun = true)
	public void setUpClass() throws MalformedURLException {
		if (gridStatus.equalsIgnoreCase("false")) {
			driver = (AppiumDriver) getDriver(getCapabilities());

		} else {
			driver.manage().window().maximize();
		}
	}

	public final selectedBrowser getBrowserType(String browser) {
		propertyfilereader = new PropertyFileReader();
		if (browser.equalsIgnoreCase("iOS_Native")) {
			return selectedBrowser.iOS_Native;
		} else if (browser.equalsIgnoreCase("Android_Native")) {
			return selectedBrowser.Android_Native;
		} else {
			return null;
		}
	}

	// @Parameters({ "googlepath"})
	public DesiredCapabilities getCapabilities() {
		switch (getBrowserType(this.browser)) {

		case iOS_Native:
			capabilities = new DesiredCapabilities();
			capabilities.setCapability("platformName", propertyfilereader.getPropertyValueOf(filepathCap, "PlatForm"));
			capabilities.setCapability("platformVersion",
					propertyfilereader.getPropertyValueOf(filepathCap, "PlatFormVersion"));
			capabilities.setCapability(MobileCapabilityType.APP,
					propertyfilereader.getPropertyValueOf(filepathCap, "appPath"));
			capabilities.setCapability("deviceName", propertyfilereader.getPropertyValueOf(filepathCap, "DeviceName"));
			break;

		case Android_Native:
			capabilities = new DesiredCapabilities();
			capabilities.setCapability("platformName", propertyfilereader.getPropertyValueOf(filepathCap, "PlatForm"));
			capabilities.setCapability("platformVersion",
					propertyfilereader.getPropertyValueOf(filepathCap, "PlatFormVersion"));
			capabilities.setCapability(MobileCapabilityType.APP,
					propertyfilereader.getPropertyValueOf(filepathCap, "appPath"));
			capabilities.setCapability("deviceName", propertyfilereader.getPropertyValueOf(filepathCap, "DeviceName"));
			capabilities.setCapability("appPackage", propertyfilereader.getPropertyValueOf(filepathCap, "appPackage"));
			capabilities.setCapability("appActivity", propertyfilereader.getPropertyValueOf(filepathCap, "appActivity"));
			capabilities.setCapability("unicodeKeyboard", "true");                                     
			capabilities.setCapability("resetKeyboard", "true");
			capabilities.setCapability("FullReset", true);
			break;
		}
		return capabilities;

	}

	@SuppressWarnings("deprecation")
	public WebDriver getDriver(DesiredCapabilities cap) throws MalformedURLException {

		switch (getBrowserType(this.browser)) {
		case iOS_Native:
			URL url = null;
			try {
				AppiumServiceBuilder builder = new AppiumServiceBuilder();
				AppiumDriverLocalService service = AppiumDriverLocalService.buildDefaultService();
				url = new URL(propertyfilereader.getPropertyValueOf(filepathCap, "AppiumURL"));
				driver = new AndroidDriver(url, cap);

			} catch (Exception e) {
				e.printStackTrace();
				;

			}
			break;
		case Android_Native:
			try {
				url = new URL(propertyfilereader.getPropertyValueOf(filepathCap, "AppiumURL"));
				driver = new AndroidDriver(url,cap);

			} catch (Exception e) {
				e.printStackTrace();

			}
			break;

		}
		return driver;
	}

	public WebDriver getRemoteDriver(DesiredCapabilities cap) throws MalformedURLException {
		driver = new AndroidDriver(new URL("http://localhost:4444/wd/hub"), cap);
		return driver;
	}

}