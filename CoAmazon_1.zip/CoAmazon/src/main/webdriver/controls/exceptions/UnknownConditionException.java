

package controls.exceptions;

public class UnknownConditionException extends RuntimeException {

    public UnknownConditionException() {
        super();
    }

    public UnknownConditionException(String s) {
        super(s);
    }
}
