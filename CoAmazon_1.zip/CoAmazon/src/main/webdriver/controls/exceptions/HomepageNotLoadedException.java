
package controls.exceptions;

public class HomepageNotLoadedException extends RuntimeException {

    public HomepageNotLoadedException() {
        super();
    }

    public HomepageNotLoadedException(String s) {
        super(s);
    }
}
