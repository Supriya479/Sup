
package controls.exceptions;

public class TooFewWindowsException extends RuntimeException {

    public TooFewWindowsException() {
        super();
    }

    public TooFewWindowsException(String s) {
        super(s);
    }
}
