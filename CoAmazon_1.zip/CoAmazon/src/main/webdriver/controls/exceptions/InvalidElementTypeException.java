
package controls.exceptions;

public class InvalidElementTypeException extends RuntimeException {

    public InvalidElementTypeException() {
        super();
    }

    public InvalidElementTypeException(String s) {
        super(s);
    }
}
