
package controls.exceptions;

public class InvalidReportFormatException extends Exception {

    public InvalidReportFormatException() {
        super();
    }

    public InvalidReportFormatException(String s) {
        super(s);
    }
}
