
package controls.exceptions;

public class UnableToFindWindowException extends RuntimeException {

    public UnableToFindWindowException() {
        super();
    }

    public UnableToFindWindowException(String s) {
        super(s);
    }
}
