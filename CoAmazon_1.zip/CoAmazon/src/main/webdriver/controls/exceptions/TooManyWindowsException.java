

package controls.exceptions;

public class TooManyWindowsException extends Exception {

    public TooManyWindowsException() {
        super();
    }

    public TooManyWindowsException(String s) {
        super(s);
    }
}
