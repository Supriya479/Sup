package ExcelUtilities;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;



public class ExcelFileReader {
	
	public Object[][] getMapArray(String xlFilePath, String sheetName,
            String tableName) throws Exception {     

     Workbook workbook = Workbook.getWorkbook(new File(xlFilePath));
     Sheet sheet = workbook.getSheet(sheetName);
     int startRow, startCol, endRow, endCol, ci, cj;
     Cell tableStart = sheet.findCell(tableName);
     startRow = tableStart.getRow();
     startCol = tableStart.getColumn();
     int endCols = sheet.getColumns();
     int endRows = sheet.getRows();
     System.out.println("startRow :" + startRow + "startCol :" + startCol);
    
     Cell tableEnd1 = sheet.findCell(tableName, startCol, startRow, endCols,
                  endRows, true);

     endRow = tableEnd1.getRow();
     endCol = tableEnd1.getColumn();
     System.out.println("startRow=" + startRow + ", endRow=" + endRow + ", "
                  + "startCol=" + startCol + ", endCol=" + endCol);


     ci = 0;
     int k = 0;
     Object[][] obj = new Object[endRow - startRow - 1][1];
     for (int i = startRow + 1; i < endRow; i++, ci++) {
            cj = 0;
              Map<Object, Object> datamap = new HashMap<>();
            for (int j = startCol + 1; j < endCol; j++, cj++) {
                  
                  datamap.put(sheet.getCell(j, startRow).getContents(),sheet.getCell(j, i).getContents());
                  
            }
            datamap.remove("");
            obj[k][0]=datamap;
            k++;
     }
     
     return (obj);

}


	
}

