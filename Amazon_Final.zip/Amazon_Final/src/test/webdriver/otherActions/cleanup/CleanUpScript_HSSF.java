//package otherActions.cleanup;
//
//import java.io.ByteArrayInputStream;
//import java.io.ByteArrayOutputStream;
//import java.io.File;
//import java.io.FileInputStream;
//import java.io.FileNotFoundException;
//import java.io.FileOutputStream;
//import java.io.IOException;
//import java.io.InputStream;
//import java.io.OutputStream;
//
//import org.apache.poi.hssf.usermodel.HSSFSheet;
//import org.apache.poi.hssf.usermodel.HSSFWorkbook;
//import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
//import org.apache.poi.ss.usermodel.Cell;
//import org.apache.poi.ss.usermodel.Row;
//import org.apache.poi.ss.usermodel.Sheet;
//import org.apache.poi.ss.usermodel.WorkbookFactory;
//import org.apache.poi.xssf.usermodel.XSSFWorkbook;
//import org.testng.annotations.AfterClass;
//import org.testng.annotations.AfterTest;
//import org.testng.annotations.Test;
//import org.testng.annotations.BeforeClass;
//
//import common.DriverSetup;
//
//
//public class CleanUpScript_HSSF extends DriverSetup {
//	public InputStream suiteInp;
//	public InputStream moduleInp;
//	public InputStream testcaseInp;
//	
//	public InputStream tcbs;
//
//	public FileOutputStream suiteOp;
//	public FileOutputStream moduleOp;
//	public FileOutputStream testcaseOp;
//
//	public HSSFWorkbook suiteWorkbook;
//	public HSSFWorkbook moduleWorkbook;
//	public HSSFWorkbook testcaseWorkbook;
//	
//	String suitePath ;
//	String modulePath ;
//	String testcasePath ;
//
//	byte[] bytes;
//	
//	@BeforeClass
//	public void beforeClass() throws InvalidFormatException {
//
//		String s2 = System.getProperty("user.dir");
//		suitePath = s2 + "\\src\\resources\\TestCase\\Suite_mod.xls";
//		modulePath = s2 + "\\src\\resources\\TestCase\\Module_mod.xls";
//		testcasePath = s2 + "\\src\\resources\\TestCase\\TestCase_mod.xls";
//
//		try {
//			suiteInp = new FileInputStream(new File(suitePath));
////			suiteOp = new FileOutputStream(new File(suitePath));
//
//			moduleInp = new FileInputStream(modulePath);
////			moduleOp = new FileOutputStream(modulePath);
//			
//			testcaseInp = new FileInputStream(testcasePath);
////			testcaseOp = new FileOutputStream(testcasePath);
//			
//			/*bytes = getBytes(suiteInp);
//			tcbs = new ByteArrayInputStream(bytes);*/
//			
//			suiteWorkbook = new HSSFWorkbook(suiteInp);
//			moduleWorkbook = new HSSFWorkbook(moduleInp);
//			testcaseWorkbook = new HSSFWorkbook(testcaseInp);
//
//		} catch (FileNotFoundException e) {
//			e.printStackTrace();
//		}
//		// Sheet sheet = suiteWorkbook.getSheet(sheetName);
//		catch (IOException e) {
//			e.printStackTrace();
//		}
//	}
//	
//	public static byte[] getBytes(InputStream stream)
//	{
//		ByteArrayOutputStream  baos = new ByteArrayOutputStream();
//		int len;
//		byte[] data = new byte[10000];
//		
//		try {
//			while((len=(stream.read(data, 0, data.length)))!=-1)
//			{
//				baos.write(data, 0, len);
//				baos.flush();
//			}
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	
//		return baos.toByteArray();
//	}
//
//	public void cleanUpSuite() {
//		int sheetCount, rowCount;
//		Sheet currentSheet;
//		Row row;
//		Cell cell;
//		sheetCount = suiteWorkbook.getNumberOfSheets();
//		for (int i = 0; i < sheetCount; i++) {
//			currentSheet = suiteWorkbook.getSheetAt(i);
//			rowCount = currentSheet.getLastRowNum();
//			for (int rowC = 5; rowC <= rowCount; rowC++) {
//				row = currentSheet.getRow(rowC);
//				cell = row.getCell(3);
//				/*
//				 * if (cell == null) cell = row.createCell(3);
//				 */
//				cell.setCellType(Cell.CELL_TYPE_STRING);
//				cell.setCellValue("Yes");
//
//				// currentSheet.getRow(rowC).getCell(3).setCellValue("yes");
//				// currentSheet.getRow(5).getCell(3).toString();
//			}
//			try {
//				suiteOp = new FileOutputStream(new File(suitePath));
//				suiteWorkbook.write(suiteOp);
//				
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//
//		}
//	}
//	@Test
//	public void cleanUpModule() {
//		int sheetCount, rowCount;
//		HSSFSheet currentSheet;
//		Row row;
//		Cell cell;
//		sheetCount = moduleWorkbook.getNumberOfSheets();
//		for (int i = 0; i < sheetCount; i++) {
//			currentSheet = moduleWorkbook.getSheetAt(i);
//			rowCount = currentSheet.getLastRowNum();
//			for (int rowC = 1; rowC <= rowCount; rowC++) {
//				row = currentSheet.getRow(rowC);
//				cell = row.getCell(1);
//				/*
//				 * if (cell == null) cell = row.createCell(3);
//				 */
//				cell.setCellType(Cell.CELL_TYPE_STRING);
//				cell.setCellValue("Yes");
//
//				// currentSheet.getRow(rowC).getCell(3).setCellValue("yes");
//				// currentSheet.getRow(5).getCell(3).toString();
//			}
//			try {
//				moduleOp = new FileOutputStream(modulePath);
//				moduleWorkbook.write(suiteOp);
////				moduleOp.close();
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//
//		}
//	}
//	@AfterClass
//	public void afterClass()
//	{
//		try {
//			suiteInp.close();
//			moduleInp.close();
//			testcaseInp.close();
//
//			suiteOp.close();
//			moduleOp.close();
//			testcaseOp.close();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
//}
