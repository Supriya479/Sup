///** 
// * @author A-5907
//
// * @Name: Nagaraju vutukuri
// * 
// * Description : Cleans/Deletes,
// * 1) temp folder
// * 2) xls folder
// * 3) screenshots folder
// * 4) In testcase.xls->under CleanUpTcTab sheet-> under Tab(s) to clean heading->suite names to be cleaned will be provided,
// *  so that script takes care of respective testcase and module files, and sets all the Run status as Yes and Execution status
// *  as blank and Bug Id will be set as blank.
// * Modified by: Arjun B M
// * Date Modified: 3/12/2015
// */
//
//package otherActions.cleanup;
//
//import java.io.File;
//import java.io.FileInputStream;
//import java.io.FileOutputStream;
//import java.io.IOException;
//import java.io.InputStream;
//import java.io.OutputStream;
//
//import org.apache.commons.io.FileUtils;
//import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
//import org.apache.poi.ss.usermodel.Cell;
//import org.apache.poi.ss.usermodel.Row;
//import org.apache.poi.ss.usermodel.Sheet;
//import org.apache.poi.ss.usermodel.WorkbookFactory;
//import org.apache.poi.xssf.usermodel.XSSFSheet;
//import org.apache.poi.xssf.usermodel.XSSFWorkbook;
//import org.testng.annotations.AfterClass;
//import org.testng.annotations.BeforeClass;
//import org.testng.annotations.Test;
//
//import common.DriverSetup;
//
//
//public class CleanUpScriptCase extends DriverSetup{
//	public InputStream suiteInp;
//	public InputStream moduleInp;
//	public InputStream testcaseInp;
//
//	public InputStream tcbs;
//
//	public OutputStream suiteOp;
//	public OutputStream moduleOp;
//	public FileOutputStream testcaseOp;
//
//	public XSSFWorkbook suiteWorkbook;
//	public XSSFWorkbook moduleWorkbook;
//	public XSSFWorkbook testcaseWorkbook;
//
//	byte[] bytes;
//
//	String suitePath;
//	String modulePath;
//	String testcasePath;
//	String xlsFolderPath;
//	String screenshotsFolderPath;
//
//	@BeforeClass
//	public void beforeClass() {
//
//		String s2 = System.getProperty("user.dir");
//		suitePath = s2 + "\\src\\resources\\TestCase\\Suite.xlsx";
//		modulePath = s2 + "\\src\\resources\\TestCase\\Module.xlsx";
//		testcasePath = s2 + "\\src\\resources\\TestCase\\TestCase.xlsx";
//		xlsFolderPath = s2 + "\\reports\\xls";
//		screenshotsFolderPath = s2 + "\\screenshots";
//	}
//
//	@Test
//	public void cleanUpTestCaseNew() throws InvalidFormatException, IOException {
//		int rowCount, rowCountMod, rowCountSheet;
//		Row rowTest, rowSheet, rowMod, rowTestCa;
//		Cell cellTest, cellSheetModuleTabName, cellSheetTestCaseTabName, cellSheetSuiteName, cellMod, cellTestCa, cpCell1, cpCell2;
//		testcaseInp = new FileInputStream(new File(testcasePath));
//		testcaseWorkbook = (XSSFWorkbook) WorkbookFactory.create(testcaseInp);
//		XSSFSheet sheetName = testcaseWorkbook.getSheet("CleanupTCTAB");
//		rowTest = sheetName.getRow(2);
//		cellTest = rowTest.getCell(9);
//		String CellValues = cellTest.getStringCellValue();
//		String[] splittedCelVal = CellValues.split("/");
//		suiteInp = new FileInputStream(suitePath);
//		suiteWorkbook = (XSSFWorkbook) WorkbookFactory.create(suiteInp);
//		XSSFSheet suiteSheetName = suiteWorkbook.getSheet("SuiteNames");
//		rowCount = suiteSheetName.getLastRowNum();
//		int length = splittedCelVal.length;
//		while (length > 0) {
//			for (int rowC = 5; rowC <= rowCount; rowC++) {
//				rowSheet = suiteSheetName.getRow(rowC);
//				cellSheetSuiteName = rowSheet.getCell(1,
//						Row.RETURN_NULL_AND_BLANK);
//				cellSheetModuleTabName = rowSheet.getCell(13);
//				cellSheetTestCaseTabName = rowSheet.getCell(14);
//
//				if (splittedCelVal[length - 1]
//						.equalsIgnoreCase(cellSheetSuiteName
//								.getStringCellValue())) {
//					// Module file updation
//					moduleInp = new FileInputStream(modulePath);
//					moduleWorkbook = (XSSFWorkbook) WorkbookFactory
//							.create(moduleInp);
//					XSSFSheet moduleSheetName = moduleWorkbook
//							.getSheet(cellSheetModuleTabName
//									.getStringCellValue());
//					rowCountMod = moduleSheetName.getLastRowNum();
//					for (int rowCo = 1; rowCo <= rowCountMod; rowCo++) {
//						rowMod = moduleSheetName.getRow(rowCo);
//						cellMod = rowMod.getCell(1, Row.RETURN_NULL_AND_BLANK);
//						cellMod.setCellType(Cell.CELL_TYPE_STRING);
//						cellMod.setCellValue("Yes");
//					}
//
//					try {
//						moduleInp.close();
//						moduleOp = new FileOutputStream(new File(modulePath));
//						moduleWorkbook.write(moduleOp);
//						moduleOp.close();
//					} catch (Exception e) {
//
//					}
//					// Testcase file updation
//					XSSFSheet tCSheetName = testcaseWorkbook
//							.getSheet(cellSheetTestCaseTabName
//									.getStringCellValue());
//					rowCountSheet = tCSheetName.getLastRowNum();
//					for (int rowCo1 = 2; rowCo1 <= rowCountSheet; rowCo1++) {
//						rowTestCa = tCSheetName.getRow(rowCo1);
//						cellTestCa = rowTestCa.getCell(3,
//								Row.RETURN_NULL_AND_BLANK);
//						cpCell1 = rowTestCa.getCell(8,
//								Row.RETURN_NULL_AND_BLANK);
//						cpCell2 = rowTestCa.getCell(9,
//								Row.RETURN_NULL_AND_BLANK);
//
//						try {
//							cellTestCa.setCellType(Cell.CELL_TYPE_STRING);
//							cellTestCa.setCellValue("Yes");
//							cpCell1.setCellType(Cell.CELL_TYPE_BLANK);
//							cpCell1.setCellValue("");
//							cpCell2.setCellType(Cell.CELL_TYPE_BLANK);
//							cpCell2.setCellValue("");
//
//						} catch (NullPointerException e) {
//							break;
//						}
//
//					}
//				}
//			}
//			length--;
//		}
//		deleteAllFiles(xlsFolderPath);
//		deleteAllFiles(screenshotsFolderPath);
//		clearTempFolder();
//		try {
//			suiteInp.close();
//			suiteOp = new FileOutputStream(new File(suitePath));
//			suiteWorkbook.write(suiteOp);
//			suiteOp.close();
//			moduleInp.close();
//			moduleOp = new FileOutputStream(new File(modulePath));
//			moduleWorkbook.write(moduleOp);
//			moduleOp.close();
//			testcaseInp.close();
//			testcaseOp = new FileOutputStream(new File(testcasePath));
//			testcaseWorkbook.write(testcaseOp);
//			testcaseOp.close();
//		} catch (IOException e) {
//
//			e.printStackTrace();
//		}
//
//	}
//
//	/*
//	 * List files in specific directory and delete all the files in that
//	 * directory
//	 */
//
//	public void deleteAllFiles(String folderPath) throws IOException {
//
//		File file = new File(folderPath);
//		// Object files contains all the files under the selected folder
//		File[] files = file.listFiles();
//		if (files != null) {// some JVMs return null for empty dirs
//			FileUtils.cleanDirectory(file);
//			System.out.println("Delete operation is Completed.");
//		}
//	}
//
//	// Clear the temp folder
//	// Gets the temp folder property from the System property.
//	public void clearTempFolder() throws IOException {
//
//		try {
//			File file = new File(System.getProperty("java.io.tmpdir"));
//			FileUtils.cleanDirectory(file);
//		}
//
//		catch (IOException e) {
//		}
//	}
//
//	// Kills the process by the name you specify to it
//	public void killProcess(String ProcessName) throws IOException {
//		Runtime.getRuntime().exec("taskkill /f /im " + ProcessName + ".exe");
//	}
//
//	public void cleanUpSuite() throws InvalidFormatException, IOException {
//		int sheetCount, rowCount;
//		Sheet currentSheet;
//		Row row;
//		Cell cell;
//		suiteInp = new FileInputStream(suitePath);
//		suiteWorkbook = (XSSFWorkbook) WorkbookFactory.create(suiteInp);
//		sheetCount = suiteWorkbook.getNumberOfSheets();
//		for (int i = 0; i < sheetCount; i++) {
//			currentSheet = suiteWorkbook.getSheetAt(i);
//			rowCount = currentSheet.getLastRowNum();
//			for (int rowC = 5; rowC <= rowCount; rowC++) {
//				row = currentSheet.getRow(rowC);
//				cell = row.getCell(3);
//				/*
//				 * if (cell == null) cell = row.createCell(3);
//				 */
//				cell.setCellType(Cell.CELL_TYPE_STRING);
//				cell.setCellValue("Yes");
//
//				// currentSheet.getRow(rowC).getCell(3).setCellValue("yes");
//				// currentSheet.getRow(5).getCell(3).toString();
//			}
//			try {
//				suiteInp.close();
//				suiteOp = new FileOutputStream(suitePath);
//				suiteWorkbook.write(suiteOp);
//				suiteOp.close();
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//
//		}
//	}
//
//	// @Test
//	public void cleanUpModule() throws InvalidFormatException, IOException {
//		int sheetCount, rowCount;
//		Sheet currentSheet;
//		Row row;
//		Cell cell;
//		moduleInp = new FileInputStream(modulePath);
//		moduleWorkbook = (XSSFWorkbook) WorkbookFactory.create(moduleInp);
//		sheetCount = moduleWorkbook.getNumberOfSheets();
//		for (int i = 0; i < sheetCount; i++) {
//			currentSheet = moduleWorkbook.getSheetAt(i);
//			rowCount = currentSheet.getLastRowNum();
//			for (int rowC = 1; rowC <= rowCount; rowC++) {
//				row = currentSheet.getRow(rowC);
//				cell = row.getCell(1);
//
//				cell.setCellType(Cell.CELL_TYPE_STRING);
//				cell.setCellValue("Yes");
//
//			}
//			try {
//				moduleInp.close();
//				moduleOp = new FileOutputStream(modulePath);
//				moduleWorkbook.write(moduleOp);
//				moduleOp.close();
//			} catch (IOException e) {
//
//				e.printStackTrace();
//			}
//
//		}
//	}
//
//	// @Test
//	public void cleanUpTestCase() throws InvalidFormatException, IOException {
//		int sheetCount, rowCount;
//		Sheet currentSheet;
//		Row row;
//		Cell cell;
//		testcaseInp = new FileInputStream(new File(testcasePath));
//		testcaseWorkbook = (XSSFWorkbook) WorkbookFactory.create(testcaseInp);
//		sheetCount = testcaseWorkbook.getNumberOfSheets();
//		for (int i = 0; i < sheetCount; i++) {
//			currentSheet = testcaseWorkbook.getSheetAt(i);
//			rowCount = currentSheet.getLastRowNum();
//			try {
//				for (int rowC = 2; rowC < rowCount; rowC++) {
//					row = currentSheet.getRow(rowC);
//					cell = row.getCell(3, Row.RETURN_NULL_AND_BLANK);
//
//					try {
//						if (cell.getStringCellValue().equalsIgnoreCase("No")) {
//							cell.setCellType(Cell.CELL_TYPE_STRING);
//							cell.setCellValue("Yes");
//						}
//					} catch (NullPointerException e) {
//						break;
//					}
//				}
//			} catch (NullPointerException e) {
//				// TODO Auto-generated catch block
//				break;
//			}
//
//		}
//		try {
//			testcaseInp.close();
//			testcaseOp = new FileOutputStream(new File(testcasePath));
//			testcaseWorkbook.write(testcaseOp);
//			testcaseOp.close();
//		} catch (IOException e) {
//
//			e.printStackTrace();
//		}
//	}
//
//	// new
//
//	// @Test
//	public void cleanUpTestCaseExecstatus() throws InvalidFormatException,
//			IOException {
//		int sheetCount, rowCount;
//		Sheet currentSheet;
//		Row row;
//		Cell cell, cpCell1, cpCell2;
//		testcaseInp = new FileInputStream(new File(testcasePath));
//		testcaseWorkbook = (XSSFWorkbook) WorkbookFactory.create(testcaseInp);
//		sheetCount = testcaseWorkbook.getNumberOfSheets();
//		for (int i = 0; i < sheetCount; i++) {
//			currentSheet = testcaseWorkbook.getSheetAt(i);
//			rowCount = currentSheet.getLastRowNum();
//			try {
//				for (int rowC = 2; rowC < rowCount; rowC++) {
//					row = currentSheet.getRow(rowC);
//					cell = row.getCell(3, Row.RETURN_NULL_AND_BLANK);
//					cpCell1 = row.getCell(8, Row.RETURN_NULL_AND_BLANK);
//					cpCell2 = row.getCell(9, Row.RETURN_NULL_AND_BLANK);
//					try {
//						if (cell.getStringCellValue().equalsIgnoreCase("YES")) {
//
//							cpCell1.setCellType(cpCell1.CELL_TYPE_BLANK);
//							cpCell1.setCellValue("");
//							cpCell2.setCellType(cpCell2.CELL_TYPE_BLANK);
//							cpCell2.setCellValue("");
//
//						}
//
//					} catch (NullPointerException e) {
//						break;
//					}
//
//				}
//			} catch (NullPointerException e) {
//				// TODO Auto-generated catch block
//				break;
//			}
//
//		}
//		try {
//			testcaseInp.close();
//			testcaseOp = new FileOutputStream(new File(testcasePath));
//			testcaseWorkbook.write(testcaseOp);
//			testcaseOp.close();
//		} catch (IOException e) {
//
//			e.printStackTrace();
//		}
//	}
//
//}
