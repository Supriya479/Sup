
/**VErifies price in product search screen and check out screen are same
 * 
 */
package module1;
import java.util.HashMap;
import java.util.Map;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.relevantcodes.extentreports.LogStatus;

import Screens.CheckOutScreen;
import Screens.Login;
import Screens.ProductSearchScreen;
import common.BaseSetup;
import common.CommonUtility;
import common.CustomFunctions;
import common.Excel;
import common.ExcelReadWrite;
import common.WebFunctions;
import common.Xls_Read;
import controls.ExcelRead;

public class TC_12345 extends BaseSetup {
	int counter = 0;
	public ExcelRead excelRead;
	public Excel excel;
	public ExcelReadWrite excelreadwrite;
	public CommonUtility commonUtility;
	String currentTestName;
	public WebFunctions libr;
	public CustomFunctions customfunctions;
	Xls_Read xls_Read;
	String path1 = System.getProperty("user.dir") + "\\src\\resources\\TestData.xls";
	String sheetName = "module1";
	public static String proppath = "\\src\\resources\\GlobalVariable.properties";
	public Login lr;
	public ProductSearchScreen pr;
	public CheckOutScreen ck;

	@BeforeClass
	public void setup() {
		testName = getTestName();
		excel = new Excel();
		excelRead = new ExcelRead();
		commonUtility = new CommonUtility();
		excelreadwrite = new ExcelReadWrite(testName, driver, getBrowser(), getScrenshotfilepath());
		xls_Read = new Xls_Read(null, xpathFilePath);
		libr = new WebFunctions(driver, excelreadwrite, xls_Read);
		customfunctions = new CustomFunctions(driver, excelreadwrite, xls_Read);
		lr= new Login(driver, excelreadwrite, xls_Read);
		pr= new ProductSearchScreen(driver, excelreadwrite, xls_Read);
		ck = new CheckOutScreen(driver, excelreadwrite, xls_Read);
		


	}

	@DataProvider(name = "TC_001")
	public Object[][] createData2() throws Exception {
		Object[][] retObjArr1 = excelRead.getMapArray(path1, sheetName, testName);
		return retObjArr1;
	}

	@Test(dataProvider = "TC_001")
	public void getTestSuite(Map<Object, Object> map) {
		libr.map = map;
		String className = this.getClass().getSimpleName();
		Map writeMap = new HashMap();
		System.out.println("className" + className);
		try {

			for (Map.Entry<Object, Object> entry : map.entrySet()) {
				System.out.println("Key = " + entry.getKey() + ", Value = " + entry.getValue());
			}
			System.out.println("The Class Name is:" + this.getClass().getName());
			libr.setExtentTestInstance(test);
			
			
			//Login
			lr.Login("UserName","Password");
			
			//search tv
			pr.enterProduct("Product");
			pr.selectProduct("Product");
			String actual=pr.getProductInformation();
			libr.verticalSwipeByPercentages(90,50,50,driver);
			pr.clickAddToCartBtn();
			
			
			//take information from product information screen
			ck.clickCartBtn();
			String checkOutPrice =ck.getProductInformationInCheckOutScreen();
			
			//verify details in checkout screen
			ck.verifyPriceIntwoScreens(actual,checkOutPrice);
			
		
			
			

		} catch (Exception e) {
			test.log(LogStatus.FAIL, "Element is not found");
			e.printStackTrace();
			Assert.assertFalse(true, "Element is not found");

		}
	}

}
