package Screens;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import common.CustomFunctions;
import common.ExcelReadWrite;
import common.Xls_Read;
import io.appium.java_client.AppiumDriver;

public class ProductSearchScreen extends CustomFunctions {

	public ProductSearchScreen(AppiumDriver driver, ExcelReadWrite excelReadWrite, Xls_Read xls_Read2) {
		super(driver, excelReadWrite, xls_Read2);

	}

	String sheetName = "ProductSearchScreen";
	public String screenName = "ProductSearchScreen";
/***
 * Enters Product in search boxand hides keyboard
 * @param Product
 * @throws InterruptedException
 */
	public void enterProduct(String Product) throws InterruptedException {
		enterValueInTextbox(sheetName, "txt_searchBox;id", Product, "Product search box", "Product search Screen");
		driver.pressKeyCode(AndroidKeyCode.ENTER);
		driver.hideKeyboard();
	}

	/**
	 * Select first product
	 * @param Product
	 * @throws InterruptedException
	 */
	public void selectProduct(String Product) throws InterruptedException {
		clickWebElement(sheetName,"btn_selectPrduct;xpath","Select Product","Product Search Screen");
	}

	/**
	 * Return Price of product
	 * @return
	 * @throws InterruptedException
	 */
	public String getProductInformation() throws InterruptedException {
		String price=driver.findElement(By.id("atfRedesign_priceblock_priceToPay")).getText();
		return price;
	}
	
	public void clickAddToCartBtn() throws InterruptedException {
		clickWebElement(sheetName,"btn_AddToCart;id","Addto cart button","Product Search Screen");
	}
	

}