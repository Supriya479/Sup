package Screens;

import org.openqa.selenium.WebDriver;

import common.CustomFunctions;
import common.ExcelReadWrite;
import common.Xls_Read;
import io.appium.java_client.AppiumDriver;

public class Login extends CustomFunctions {

	public Login(AppiumDriver driver,
			ExcelReadWrite excelReadWrite, Xls_Read xls_Read2) {
		super(driver, excelReadWrite, xls_Read2);

	}

	String sheetName = "Login";
	public String screenName = "Login";

/***
 * Enters Username,password and click on sign in button
 * @param UserName
 * @param Password
 * @throws InterruptedException
 */
	public void Login(String UserName,String Password) throws InterruptedException{
		clickWebElement(sheetName,"btn_signIn;id","Sign In button","Login Screen");
		enterValueInTextbox(sheetName,"txt_emailID;id",UserName,"Email","Login Screen");
		clickWebElement(sheetName,"btn_continue;id","Continue button","Login Screen");
		enterValueInTextbox(sheetName,"txt_password;id",Password,"Password","Login Screen");
		clickWebElement(sheetName,"btn_SignIn;id","Sign-In button","Login Screen");
	}
}
