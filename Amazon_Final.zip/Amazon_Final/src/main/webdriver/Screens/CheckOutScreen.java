package Screens;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import common.CustomFunctions;
import common.ExcelReadWrite;
import common.Xls_Read;
import io.appium.java_client.AppiumDriver;

public class CheckOutScreen extends CustomFunctions {

	public CheckOutScreen(AppiumDriver driver, ExcelReadWrite excelReadWrite, Xls_Read xls_Read2) {
		super(driver, excelReadWrite, xls_Read2);

	}

	String sheetName = "CheckOutScreen";
	public String screenName = "CheckOutScreen"; 
		
		
		
		public void clickCartBtn() throws InterruptedException {
			clickWebElement(sheetName,"btn_cartBtnIcon;id","basket Icon","Check Out Screen");
		}
		

		
		
		public String getProductInformationInCheckOutScreen() throws InterruptedException {
			String Checkprice=driver.findElement(By.id("atfRedesign_priceblock_priceToPay")).getText();
			String check=Checkprice.substring(0,1);
			return check;
		}




		public void verifyPriceIntwoScreens(String actual, String checkOutPrice) {
			
			if(actual.equals(checkOutPrice)){
				onPassUpdate(screenName, actual,checkOutPrice,
						"Verify price in product search screen and checkoutPrice",
						"");
			}
			else{
				onFailUpdate(screenName, actual,checkOutPrice,
						"Verify price in product search screen and checkoutPrice",
						"");
		}

}
}
