
package controls.exceptions;

public class UnknownBrowserException extends RuntimeException {

    public UnknownBrowserException() {
        super();
    }

    public UnknownBrowserException(String s) {
        super(s);
    }
}
