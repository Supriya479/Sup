
package controls.exceptions;

public class IDECommandNotFoundException extends Exception {


	public IDECommandNotFoundException() {
        super();
    }

    public IDECommandNotFoundException(String s) {
        super(s);
    }
}
