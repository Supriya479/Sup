package common;

/*****Author name: A-7290 A-7626 and A-7688
 * Description: Common methods for Web Elements
 Date of creation: 29-05-18******/

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.PropertyPermission;
import java.util.Random;
import java.util.Set;
import java.util.TimeZone;
import java.util.function.Function;

import org.openqa.selenium.Keys;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import bsh.ParseException;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import controls.ExcelRead;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import sun.security.util.SecurityConstants;

public class WebFunctions {
	public String CHAR_LIST = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
	public int RANDOMSTRINGLENGTH = 10;
	public static AppiumDriver driver;
	ExcelReadWrite excelReadWrite;
	public String excelfilename = null;
	public ExcelReadWrite excelreadwrite;
	public ExcelRead excelRead;
	public static ExtentTest test;
	Object[][] retObjArr = null;
	// String currentTestName;
	public Actions action;
	boolean j = false;
	public CommonUtility commonUtility;
	public Xls_Read xls_Read;

	public int counter = 0;
	public Actions actions;
	public Alert alert;
	public String alertText;
	public WebElement ele;
	public boolean Status = true;
	static String windowHandle;
	static String referenceVar;
	public static String childWindow;
	public static String parentWindow;
	public static String firstChildWindow;
	public static Map<Object, Object> map;
	public static List<String> failedCases = new ArrayList<String>();
	public static CustomFunctions customFunction;
	public String projDir = System.getProperty("user.dir");
	public String globalVarPath = "\\src\\resources\\GlobalVariable.properties";
	public String filePathDownload = System.getProperty("user.dir") + "\\src\\resources\\Downloads\\";
	public String autoItPath = projDir + "\\autoIt\\File.exe";
	JavascriptExecutor js = (JavascriptExecutor) driver;
	public Wait wait;
	// Winium driver initialisation

	// winium driver path

	public static String winium_driver_path = System.getProperty("user.dir") + "\\lib\\Winium.Desktop.Driver.exe";

	public WebFunctions(AppiumDriver driver, ExcelReadWrite excelReadWrite, Xls_Read xls_Read2)

	// Initializing variables
	{

		this.driver = driver;
		this.excelreadwrite = excelReadWrite;
		commonUtility = new CommonUtility();
		this.xls_Read = xls_Read2;
		excelRead = new ExcelRead();
		excelfilename = this.getClass().getSimpleName();
		actions = new Actions(driver);
		customFunction = new CustomFunctions(driver, excelReadWrite, xls_Read2);
	}

	WebElement element;
	String testSteps, pageName, eleName;

	// Zero Parameter constructor
	public WebFunctions() {
	}

	public ExtentTest getExtentTestInstance() {
		return this.test;
	}

	public void setExtentTestInstance(ExtentTest test) {
		this.test = test;
	}

	/**
	 * Description... Takes Object Map keys, returns the value of key
	 * 
	 * @param keyName
	 * @return Map values
	 */

	public String data(String keyName) {

		try {

			if (keyName.contains("prop~"))

			{

				String keyVal = keyName.split("~")[1].toString();

				return (getPropertyValue(globalVarPath, keyVal));

			}

			else if (keyName.contains("val~")) {

				return (keyName.split("~")[1].toString());
			} else {
				return (String) map.get(keyName);
			}
		} catch (Exception e) {
			test.log(LogStatus.FAIL, "Could not fetch correct data value");
			System.out.println(e);
		}
		return null;
	}

	/**
	 * Author : A-8705 Purpose : Common Method to scroll till Webelement
	 * 
	 */
	public void scrollTillElement(String sheetName, String locator, String screenName, String eleName) {
		By b = getElement(sheetName, locator);
		WebElement ele = driver.findElement(b);
		JavascriptExecutor ex = (JavascriptExecutor) driver;
		ex.executeScript("arguments[0].scrollIntoView(true);", ele);
		test.log(LogStatus.PASS, "Successfully scrolled till" + eleName + " On " + screenName);
	}

	/**
	 * Description... Clicks links, button, radio button, check box
	 * 
	 * @param sheetName
	 *            Xpath Sheetname
	 * @param locator
	 *            Xpath Locator name
	 * @param eleName
	 *            used for reporting purpose. example OK Button
	 * @param ScreenName
	 *            used for reporting purpose. example Login Page
	 * @throws InterruptedException
	 */

	public void clickWebElement(String sheetName, String locator, String eleName, String ScreenName)
			throws InterruptedException {
		By element = getElement(sheetName, locator);
		try {
			driver.findElement(element).click();
			writeExtent("Pass", "clicked on " + eleName + " On " + ScreenName + " Page");
			System.out.println("click on " + eleName + " On " + ScreenName + " Page");
		} catch (Exception e) {
			e.printStackTrace();
			writeExtent("Fail", "Could not click on " + eleName + " On " + ScreenName + " Page");
			Assert.assertFalse(true, "Could not click on " + eleName + " On " + ScreenName + " Page");;
		}
	}

	public static void verticalSwipeByPercentages(double startPercentage, double endPercentage, double anchorPercentage,
			AppiumDriver androidDriver) {
		Dimension size = androidDriver.manage().window().getSize();
		System.out.println(size);
		int anchor = (int) (size.width * anchorPercentage) / 100;
		int startPoint = (int) (size.height * startPercentage) / 100;
		int endPoint = (int) (size.height * endPercentage) / 100;
		new TouchAction(androidDriver)
				.press(point(anchor, startPoint))
				.moveTo(point(anchor, endPoint))
				.release().perform();
		System.out.println("test");

	}

	
	public void onPassUpdate(String screenName, String expText, String actText, String functinalityName,
			String testSteps) {
		try {
			counter = counter + 1;
			excelreadwrite.insertData(DriverSetup.testName,

					commonUtility.getcurrentDateTime() + "_" + String.valueOf(counter),
					"Verify the functionality " + functinalityName + " On " + screenName + " Screen",

					testSteps, "Expected Value is : " + expText + " \nActual value is : " + actText, true, "No",

					actText, expText);
			test.log(LogStatus.PASS, "Successfully Verified " + expText + " On " + screenName);
			System.out.println("Successfully Verified " + expText + "On" + screenName);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void onFailUpdate(String screenName, String expText, String actText, String functinalityName,
			String testSteps) {
		counter = counter + 1;
		excelreadwrite.insertFailedData(DriverSetup.testName,
				commonUtility.getcurrentDateTime() + "_" + String.valueOf(counter),
				"Verify the functionality " + functinalityName + " On " + screenName + " Screen", testSteps,
				"Expected Value is : " + expText + " \nActual value is : " + actText, false, "", actText,

				expText);
		test.log(LogStatus.FAIL, "Failed to Verify " + expText);
		System.out.println("Failed to Verify " + expText);
		Assert.assertFalse(true, "Element is not found");

	}
	/**
	 * * Description... Gets the property value for the key from the property
	 * file
	 * 
	 * @param s3
	 * @param Key
	 * @return Value of the key
	 */

	public static String getPropertyValue(String s3, String Key) {
		Properties prop = new Properties();
		String s2 = System.getProperty("user.dir");
		String path = s2 + s3;
		try {
			prop.load(new FileInputStream(path));
		} catch (Exception e) {

		}
		String value = prop.getProperty(Key);
		return value;
	}

	public static String setProperty(String key, String value) {
		checkKey(key);
		SecurityManager sm = getSecurityManager();
		if (sm != null) {
			sm.checkPermission(new PropertyPermission(key, SecurityConstants.PROPERTY_WRITE_ACTION));
		}

		return (String) props.setProperty(key, value);
	}

	/**
	 * 
	 * Description... Checks for DetailedReport key in Global Variable
	 * properties. If DetailedReport=Yes then logs all the operations otherwise
	 * logs what is logged using test.log
	 * 
	 * @param Status
	 *            Pass/Fail
	 * @param Details
	 */
	public void writeExtent(String Status, String Details) {
		String reportDetails = getPropertyValue(customFunction.proppath, "DetailedReport");
		try {
			if (reportDetails.equalsIgnoreCase("Yes")) {
				if (Status.equals("Pass"))
					test.log(LogStatus.PASS, Details);
				else if (Status.equals("Fail"))
					test.log(LogStatus.FAIL, Details);
				else if (Status.equals("Info"))
					test.log(LogStatus.INFO, Details);

			}
		} catch (Exception e) {
			System.out.println("Failed in creating Extent Object");
			System.out.println(e);
		}
	}

	public By getElement(String sheetName, String object) {

		try {

			By element = null;
			String locatorType = null;
			String locatorName = null;
			locatorType = object.split(";")[1].toString();
			locatorName = xls_Read.getCellValue(sheetName, object);
			String locator = xls_Read.getCellValue(sheetName, object, "Locators");

			System.out.println("locatorType" + locatorType);
			System.out.println("locatorName" + locatorName);
			System.out.println("locatorName" + locator);
			// Finding the element

			switch (locator) {
			case "xpath":
				element = By.xpath(locatorName);
				break;
			case "name":
				element = By.name(locatorName);
				break;
			case "id":
				element = By.id(locatorName);
				break;
			case "linkText":
				element = By.linkText(locatorName);
				break;
			case "partialLinkText":
				element = By.partialLinkText(locatorName);
				break;
			case "tagname":
				element = By.tagName(locatorName);
				break;
			case "cssSelector":
				element = By.cssSelector(locatorName);
				break;
			case "className":
				element = By.className(locatorName);
				break;
			}
			/***** waitTillOverlayDisappear(element, driver); ***/
			return element;
		}

		catch (Exception e) {
			return null;
		}

	}

	/**
	 * Description...Multiplies SyncTime from GlobalVariable.properties to the
	 * number of seconds sent as argument
	 * 
	 * @param i
	 *            seconds to wait
	 */
	// wait for sync
	public void waitForSync(int i) {
		try {
			String path = customFunction.proppath;
			int syncTime = Integer.parseInt(getPropertyValue(path, "SyncTime"));
			int j = i * 1000 * syncTime;
			Thread.sleep(j);
			System.out.println("Waited for " + (i * syncTime) + " seconds...");
		} catch (Exception e) {

		}
	}

	/**
	 * Description... enter text in a text box/ text area
	 * 
	 * @param sheetName
	 *            Xpath Sheetname
	 * @param locator
	 *            Xpath Locator name
	 * @param eleName
	 *            used for reporting purpose. example OK Button
	 * @param ScreenName
	 *            used for reporting purpose. example Login Page
	 * @throws InterruptedException
	 */
	public void enterValueInTextbox(String sheetName, String locator, String value, String eleName, String ScreenName)
			throws InterruptedException {
		try {
			By element = getElement(sheetName, locator);
			driver.findElement(element).click();
			driver.findElement(element).clear();
			waitForSync(1);
			driver.findElement(element).sendKeys(value);
			writeExtent("Pass", "Entered " + value + " as " + eleName + " on " + ScreenName + " Page");
			System.out.println("Entered " + value + " as " + eleName + " on " + ScreenName + " Page");

		} catch (Exception e) {
			System.out.println("Could not enter " + value + " as " + eleName + " on " + ScreenName + " Page");
			writeExtent("Fail", "Could not enter " + value + " as " + eleName + " on " + ScreenName + " Page");
			Assert.assertFalse(true, "Could not enter " + value + " as " + eleName + " on " + ScreenName + " Page");
		}

	}

}